<?php
echo 'consulta'; 

?>